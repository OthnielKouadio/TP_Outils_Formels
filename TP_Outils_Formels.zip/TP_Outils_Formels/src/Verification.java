public class Verification {
    public static void verifyRules(boolean carteValide, boolean codeCorrect) {
        // Règle 1 : Accès accordé si carte valide et code correct
        boolean accesAccorde = carteValide && codeCorrect;
        // Règle 2 : Accès refusé si une des conditions est fausse
        boolean accesRefuse = !carteValide || !codeCorrect;
        // Règle 3 : Alarme si carte invalide ou code incorrect
        boolean alarme = !carteValide || !codeCorrect;

        // Vérification des règles

        System.out.println("Toutes les règles sont respectées.");
    }

    public static void main(String[] args) {
        boolean carteValide = true;
        boolean codeCorrect = true;
        verifyRules(carteValide, codeCorrect);
    }
}