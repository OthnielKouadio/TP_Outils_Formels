public class LogicCircuits {
    public static void main(String[] args) {
        boolean carteValide = true;  // Entrée 1
        boolean codeCorrect = false; // Entrée 2

        // Sorties basées sur l'algèbre de Boole
        boolean accesAccorde = false;
        boolean accesRefuse = true;
        boolean alarme = true;

        // Affichage des résultats
        System.out.println("Accès accordé: " + accesAccorde);
        System.out.println("Accès refusé: " + accesRefuse);
        System.out.println("Alarme: " + alarme);

    }
}