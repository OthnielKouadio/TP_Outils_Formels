import java.util.Scanner;

public class Automate {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String state = "q0"; // État initial

        while (true) {
            System.out.println("État actuel : " + state);
            switch (state) {
                case "q0": // Attente d'une carte
                    System.out.println("Présenter une carte (valide: 1, invalide: 0): ");
                    int carte = scanner.nextInt();
                    state = (carte == 1) ? "q1" : "q4";
                    break;
                case "q1": // Vérification du code
                    System.out.println("Entrer le code (correct: 1, incorrect: 0): ");
                    int code = scanner.nextInt();
                    state = (code == 1) ? "q3" : "q4";
                    break;
                case "q3": // Accès accordé
                    System.out.println("Accès accordé.");
                    return;
                case "q4": // Accès refusé ou alarme
                    System.out.println("Accès refusé ou alarme déclenchée.");
                    return;
                default:
                    System.out.println("État inconnu.");
                    return;
            }
        }
    }
}