public class AccessControl {
    public static void main(String[] args) {
        boolean carteValide = true;  // Indique si la carte est valide
        boolean codeCorrect = true; // Indique si le code est correct

        if (carteValide && codeCorrect) {
            System.out.println("Accès accordé");
        } else if (!carteValide || !codeCorrect) {
            System.out.println("Accès refusé");
        }

        if (!carteValide || (!codeCorrect && carteValide)) {
            System.out.println("Alarme déclenchée");
            }
    }
}